/*
 * Compilers
 * Practice 1: c pre-processor
 * File name: comp-p1.c
 * Main program file
 * Additional files: comp-p1.h, comp-p1.c, lib1.h, lib1.c
 * 
 * Responsible: ALBA YERGA, ROGER VIADER, ORIOL ROCA, ADRIA SORIA
 */
/*
 * Compilers
 * Practice 1: c pre-processor
 * File name: comp-p1.h
 * General data structures and definitions of the pre-processor
 *
 * Responsible: ALBA YERGA, ROGER VIADER, ORIOL ROCA, ADRIA SORIA
 *
 */

//this is stdio.h included file
//this is stdlib.h included file

//this is stdio.h included file
//this is string.h included file
